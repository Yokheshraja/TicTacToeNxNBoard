package com.game.tictactoenxnboard;

public class TicTacToeNxNBoardMain {
    //didn't want many lines in main
    public static void main(String[] args) {
        GameLogic gameStart = new GameLogic();
        gameStart.gameStart();
    }
}
